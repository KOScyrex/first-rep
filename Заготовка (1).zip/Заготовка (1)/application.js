const burger_icon = document.querySelector('.menu_small_icon')
const mob_menu = document.querySelector('.menu-small')
let is_hide_mob_menu = true

function show_mob_menu() {
  mob_menu.animate( {
    'right': -2100%
  })
  is_hide_mob_menu = false
}

let is_hidden = true
let burger = $('.menu_small_icon')

function show_menu() {
    anime({
        targets: '.menu-small',
        translateX: ['-100%', '0'],
        duration: 1000,
        easing: "easeInOutQuad"
    })
    is_hidden = false
}

show_menu()

function hide_menu() {
    anime({
        targets: '.menu-small',
        translateX: ['0', '-100%'],
        duration: 1000,
        easing: "easeInOutQuad"
    })
    is_hidden = true
}

burger.on('click', function () {
    if(is_hidden) {
        show_menu()
    } else{
        hide_menu()
    }
})

let startX = 0;
let endX = 0;
$(document).on('touchstart', function (event) {
    startX = event.originalEvent.touches[0].pageX
})

$(document).on('touchend', function (event) {
    endX = event.originalEvent.changedTouches[0].pageX
    if (startX = endX < -100 && is_hidden) {
        show_menu();
    } else if (startX - endX > -100 && !is_hidden) {
        hide_menu();
    }
})